-- Bullet effects (client): keeps ACF's simulated bullets alive past the engine's placement limit, shows their tracer there, and
-- says what is wrong when a bullet model is not drawn.
--
-- ACF simulates every bullet on the client (ACF.BulletEffect[Index], moved each tick by EFFECT:ApplyMovement) and the effect
-- entity is only the thing that draws it. Three things go wrong under InfMap, and this file handles each of them:
--
--  1. ACF kills the effect when the bullet is more than 16380 units from the frame origin (ApplyMovement, SEEN). Under InfMap the
--     frame origin is the CENTRE of your chunk, so a shell leaves that box after about one chunk. The hit message that arrives
--     later ("Update", Scale > 0) finds no entry and creates nothing: no AP impact, no penetration, no ricochet. That is the
--     "hit effects stop one chunk away" half that is not about drawing. Fix: from the window edge on, ApplyMovement is replaced
--     for that bullet: the simulation keeps running, the engine entity is hidden, and the tracer is added to the replay renderer
--     (cl_replay.lua) instead of an engine emitter. Inside the window ACF's own code runs untouched.
--  2. The engine will not place or draw anything outside that box (see cl_replay.lua), so the tracer beyond it needs the replay
--     renderer anyway.
--  3. A bullet model that never appears. The cause is not known (see below), so this file measures instead of guessing: it counts
--     how often the engine really calls the effect's Render, and when a bullet inside the window gets no Render calls at all it
--     draws the model itself from ACF's own simulation state and reports that it did. `acf_infmap_bulletdebug` and
--     `acf_infmap_status` show the counters; `acf_infmap_bullettest` creates a harmless test shell through ACF's real effect.
--
-- Evidence labels: SEEN = read in source / run in the mock, KNOWN = standard GMod behaviour not re-checked, GUESS = needs a game.
--   SEEN:  ApplyMovement kills at |x| or |y| > 16380 or z < -16380, otherwise SetPos + tracer particles; Think keeps the effect for
--          45 s unless Kill is set; the hit message sets Kill itself (effects/acf_bullet_effect.lua).
--   SEEN:  ACF's own missile code replaces Effect.ApplyMovement per instance in the ACF_OnCreateBulletEffect hook
--          (missiles/acfm_effects_cl.lua). This file uses the same hook and the same replacement. The hook order between two
--          addons is not defined, so the replacement is re-checked every tick.
--   SEEN:  the tracer is one stretched sprite per tick (sprites/acf_tracer.vmt, alpha 255) plus two smoke puffs that start at alpha
--          10 and size 1. Far away only the sprite can be seen, so only it is replayed.
--   GUESS: that the engine calls a per-instance Render function. If it does not, the Render counter stays 0, this addon draws the
--          model as well, and the two copies sit in the same place and look like one. The counter then proves nothing about the
--          engine, and the status line says so.
--   GUESS: that a stretched particle sprite is drawn from its position back along its direction.
--   GUESS: that ACF's Init runs inside util.Effect (the test command checks it and prints the answer).

local Compat = ACFInfMapCompat
local Stats  = Compat.Stats

local On      = CreateClientConVar("acf_infmap_cl_bullets", "1", true, false, "1 = keep ACF bullets alive past the engine's placement limit and draw their tracers there. 0 = stock behaviour.", 0, 1)
local OwnDraw = CreateClientConVar("acf_infmap_cl_bullet_draw", "1", true, false, "1 = if the engine never draws a bullet's model, draw it from ACF's own simulation state.", 0, 1)

local Bullets = {}

Compat.Bullets = Bullets
Bullets.Errors = Bullets.Errors or 0

local FramesBeforeDiagnosis = 3 -- rendered frames a new bullet gets before "never drawn" is concluded

local function Alive(Effect) return Effect ~= nil and IsValid(Effect) end

-- ---------------------------------------------------------------------------------------------------- far tracer
--- The tracer sprite ACF would add this tick, added to the replay renderer. Same values as effects/acf_bullet_effect.lua.
local function FarTracer(Effect, Bullet)
	local Replay = Compat.Replay

	if not Replay or not Bullet.Tracer or not IsValid(Bullet.Tracer) or not Bullet.Color then return end

	local Emitter = Effect.ACFInfMapFarEmitter

	if not Emitter then
		Emitter = Replay.NewEmitter(Bullet.SimPos, true)
		Effect.ACFInfMapFarEmitter = Emitter
	end

	local Length = math.max((Bullet.SimPos - Bullet.SimPosLast):Length() * 2, 1)
	local Color  = Bullet.Color
	local Light  = Emitter:Add("sprites/acf_tracer.vmt", Bullet.SimPosLast)

	if not Light then return end

	Light:SetAngles(Bullet.SimFlight:Angle())
	Light:SetVelocity(Bullet.SimFlight:GetNormalized())
	Light:SetColor(Color.r, Color.g, Color.b)
	Light:SetDieTime(0.075)
	Light:SetStartAlpha(255)
	Light:SetEndAlpha(0)
	Light:SetStartSize(Bullet.Caliber * 15)
	Light:SetEndSize(Bullet.Caliber * 15)
	Light:SetStartLength(Length)
	Light:SetEndLength(Length)
end

-- ---------------------------------------------------------------------------------------------------- movement
local function EnterFar(Effect, Bullet)
	Effect.ACFInfMapFar = true

	if not Effect.ACFInfMapCounted then
		Effect.ACFInfMapCounted = true
		Stats.BulletsKeptAlive = Stats.BulletsKeptAlive + 1
	end

	-- The entity stays where ACF last put it, at the edge of the box, so it must not be drawn there
	Effect:SetNoDraw(true)
end

local function LeaveFar(Effect)
	Effect.ACFInfMapFar = false

	Effect:SetNoDraw(false)
end

--- Replacement for Effect.ApplyMovement. Inside the window it is ACF's function, called unchanged.
local function MakeMovement(Original)
	return function(self, Bullet)
		if not On:GetBool() or Bullet.AmmoType == "FLR" then return Original(self, Bullet) end -- flares have their own limit (16000)

		local Pos = Bullet.SimPos

		if Compat.InWindow(Pos) then
			if self.ACFInfMapFar then LeaveFar(self) end

			return Original(self, Bullet)
		end

		-- Beyond the cap nobody would be sent the hit anyway (the server sends to its effect range), so the bullet ends here
		local Replay = Compat.Replay
		local Eye    = EyePos()

		if Replay and Pos:Distance(Eye) > Replay.Range() then
			self.Kill = true

			return
		end

		if not self.ACFInfMapFar then EnterFar(self, Bullet) end

		if self.DrawEffect then FarTracer(self, Bullet) end
	end
end

--- Makes sure the instance carries the replacement and the Render counter. Called when the effect is created and again every tick.
local function Ensure(Effect)
	if Effect.ApplyMovement ~= Effect.ACFInfMapMove then
		local Wrapped = MakeMovement(Effect.ApplyMovement)

		Effect.ACFInfMapMove = Wrapped
		Effect.ApplyMovement = Wrapped
	end

	if Effect.Render ~= Effect.ACFInfMapRender then
		local Original = Effect.Render
		local Counted  = function(self)
			self.ACFInfMapRenders = (self.ACFInfMapRenders or 0) + 1

			return Original(self)
		end

		Effect.ACFInfMapRender = Counted
		Effect.Render = Counted
	end
end

hook.Add("ACF_OnCreateBulletEffect", "ACFInfMapCompat_Bullets", function(Effect)
	if not Alive(Effect) then return end

	Effect.ACFInfMapBorn    = CurTime()
	Effect.ACFInfMapRenders = 0
	Effect.ACFInfMapFrames  = 0

	Ensure(Effect)
end)

hook.Add("ACF_OnTick", "ACFInfMapCompat_BulletKeep", function()
	if Bullets.Disabled then return end

	local OK, Err = pcall(function()
		for _, Bullet in pairs(ACF.BulletEffect or {}) do
			local Effect = Bullet.Effect

			if Alive(Effect) then Ensure(Effect) end
		end
	end)

	if OK then return end

	Bullets.Errors = Bullets.Errors + 1

	if Bullets.Errors == 1 then Compat.Warn("Bullet keep-alive raised an error: ", tostring(Err)) end

	if Bullets.Errors >= 5 then
		Bullets.Disabled = true

		Compat.Warn("Bullet keep-alive raised errors five times and switched itself off. Reload the map to retry.")
	end
end)

-- ---------------------------------------------------------------------------------------------------- own drawing
local Csents = {}

local function Model(Path)
	local Ent = Csents[Path]

	if not IsValid(Ent) then
		Ent = ClientsideModel(Path, RENDERGROUP_OPAQUE)

		if not IsValid(Ent) then return nil end

		Ent:SetNoDraw(true)

		Csents[Path] = Ent
	end

	return Ent
end

--- Draws one bullet's model from ACF's simulation state (position, direction, model, scale).
local function DrawBullet(Effect, Bullet)
	local Path = Effect:GetModel()

	if not Path or Path == "" then return end

	local Ent = Model(Path)

	if not Ent then return end

	Ent:SetModelScale(Effect:GetModelScale() or 1, 0)
	Ent:SetPos(Bullet.SimPos)
	Ent:SetAngles(Bullet.SimFlight:Angle())
	Ent:SetupBones()
	Ent:DrawModel()
end

hook.Add("PostDrawOpaqueRenderables", "ACFInfMapCompat_BulletDraw", function(_, Skybox, Skybox3D)
	if Skybox or Skybox3D or Bullets.Disabled or not On:GetBool() then return end

	local OK, Err = pcall(function()
		for _, Bullet in pairs(ACF.BulletEffect or {}) do
			local Effect = Bullet.Effect

			if Alive(Effect) and not Effect.ACFInfMapFar then
				Effect.ACFInfMapFrames = (Effect.ACFInfMapFrames or 0) + 1

				-- The engine draws opaque entities before this hook, so a drawn bullet has been counted by now
				if (Effect.ACFInfMapRenders or 0) > 0 then
					Effect.ACFInfMapOwn = false
				elseif Effect.ACFInfMapFrames >= FramesBeforeDiagnosis and Effect.DrawEffect and OwnDraw:GetBool() then
					if not Effect.ACFInfMapOwn then
						Effect.ACFInfMapOwn = true
						Stats.BulletNeverDrawn = Stats.BulletNeverDrawn + 1

						Compat.WarnOnce("neverdrawn", "The engine did not draw ACF's bullet model (bullet #", Bullet.Index,
							") although the bullet is inside the placeable area. This addon is drawing the model itself from ACF's simulation. ",
							"If the Render counter is not trustworthy on your install, the model may now be drawn twice in the same place, which looks the same. Run acf_infmap_bulletdebug.")
					end
				end

				if Effect.ACFInfMapOwn and Effect.DrawEffect and Bullet.SimPos and Bullet.SimFlight then DrawBullet(Effect, Bullet) end
			end
		end
	end)

	if OK then return end

	Bullets.Errors = Bullets.Errors + 1

	if Bullets.Errors == 1 then Compat.Warn("Bullet drawing raised an error: ", tostring(Err)) end

	if Bullets.Errors >= 5 then
		Bullets.Disabled = true

		Compat.Warn("Bullet drawing raised errors five times and switched itself off. Reload the map to retry.")
	end
end)

-- ---------------------------------------------------------------------------------------------------- test
--- A slow, harmless shell made through ACF's real effect (util.Effect("acf_bullet_effect")), 300 units in front of you.
--- The nearest ammo crate with tracers on is used as the shell's crate when there is one, otherwise you are.
--- It answers the question "does ACF's own bullet effect draw here at all?" without the server, the network or a gun.
local TestIndex = 1000000 -- real bullet indexes stay below 2000 (ballistics_sv.lua, IndexLimit)

concommand.Add("acf_infmap_bullettest", function(_, _, Args)
	local Meters = tonumber(Args and Args[1]) or 0 -- how far away to put it: 0 = right in front of you
	local Eye    = EyePos()
	local Aim    = EyeAngles():Forward()
	local Pos    = Eye + Aim * (300 + Meters * Compat.MeterToUnit)
	local Crate  = LocalPlayer()
	local Tracer = false

	for _, Ent in ipairs(ents.FindByClass("acf_ammo")) do
		if IsValid(Ent) and Ent:GetNW2Float("Tracer") > 0 then
			Crate  = Ent
			Tracer = true

			break
		end
	end

	TestIndex = TestIndex + 1

	local Data = EffectData()

	Data:SetDamageType(TestIndex)
	Data:SetStart(Aim * 60) -- ACF multiplies it by 10: 600 units per second, away from you
	Data:SetAttachment(1)
	Data:SetOrigin(Pos)
	Data:SetScale(0)
	Data:SetEntity(Crate)

	local Mine = Pos:Distance(Eye)

	util.Effect("acf_bullet_effect", Data, true, true)

	local Entry   = ACF.BulletEffect and ACF.BulletEffect[TestIndex]
	local Created = Entry ~= nil

	Compat.Say("test shell ", string.format("%.0f", Mine), " units ahead of you, crate = ", Tracer and "a tracer crate" or "yourself (no tracer)",
		". Init ran inside util.Effect: ", Created and "yes" or "NO", ". You should see a small shell moving away from you for about 4 seconds.")

	if not Created then
		Compat.Warn("ACF's bullet effect did not register the shell. That means its Init gave up before building the bullet. Run acf_infmap_status and send me the output.")

		return
	end

	timer.Simple(1, function()
		local Now = ACF.BulletEffect and ACF.BulletEffect[TestIndex]

		if not Now or not Alive(Now.Effect) then
			Compat.Warn("test shell: already gone after 1 s (killed or removed).")

			return
		end

		local Effect = Now.Effect

		Compat.Say(string.format("test shell after 1 s: engine called Render %d time(s), %d frame(s) seen, this addon draws it itself: %s, far: %s",
			Effect.ACFInfMapRenders or 0, Effect.ACFInfMapFrames or 0, Effect.ACFInfMapOwn and "yes" or "no", Effect.ACFInfMapFar and "yes" or "no"))
	end)

	timer.Simple(4, function()
		local Now = ACF.BulletEffect and ACF.BulletEffect[TestIndex]

		if Now and Alive(Now.Effect) then Now.Effect.Kill = true end
	end)
end)

Compat.Register("cl_bullets", function()
	Compat.Status["bullet effects (keep-alive, far tracer)"] = "active"
end)

Compat.StatusLines.cl_bullets = function()
	local Far, Own, Drawn, Total = 0, 0, 0, 0

	for _, Bullet in pairs(ACF.BulletEffect or {}) do
		local Effect = Bullet.Effect

		if Alive(Effect) then
			Total = Total + 1

			if Effect.ACFInfMapFar then Far = Far + 1 end
			if Effect.ACFInfMapOwn then Own = Own + 1 end
			if (Effect.ACFInfMapRenders or 0) > 0 then Drawn = Drawn + 1 end
		end
	end

	return {
		string.format("bullets: keep-alive %s, %d simulated now (%d beyond the window, %d drawn by the engine, %d drawn by this addon)", (On:GetBool() and not Bullets.Disabled) and "ON" or "OFF", Total, Far, Drawn, Own),
		string.format("bullets: kept alive past the limit %d, model never drawn by the engine %d, new bullets refused by ACF %d", Stats.BulletsKeptAlive, Stats.BulletNeverDrawn, Stats.BulletRefused),
	}
end
