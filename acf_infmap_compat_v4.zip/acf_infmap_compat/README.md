# ACF3 <-> InfMap compatibility (standalone addon), version 4

One addon folder. It edits neither ACF nor InfMap: it wraps ACF's own functions at runtime, keeps the originals, and does nothing on maps that are not InfMap maps. Delete the folder and you are back to stock behaviour.

Built for the **original InfMap** (meetric1's "Infinite Map Base", the Workshop one, `chunk_size = 10000`) and ACF-3 master.

Labels used everywhere (here and in the headers of every `.lua` file):

- **SEEN** = read in the ACF / InfMap source, or exercised against ACF's real files in the test harness.
- **KNOWN** = standard GMod / Source behaviour that I did not re-check.
- **GUESS** = inference. Only a real game can confirm it.

## What changed in version 4

Your report after version 3: hit effects still stop about a chunk away (you want three at minimum), the bullet is still not visible, and **no band-aids**.

Version 3's far "stand-ins" were a band-aid: a made-up flash and streak, built on a guess about the engine. They are gone (`cl_far.lua` no longer exists). Version 4 shows ACF's **own** effects instead.

### Hit effects: why they stopped, and what replaces it

There were four separate limits, and three of them were in my own defaults or in ACF:

| Limit | Evidence | Version 4 |
|---|---|---|
| Server only sent an effect to players within 45000 units (about 1.1 km) | SEEN (my own default) | Default **120000 units (about 3 km, six chunks)**, adjustable up to 400000. A saved 30000 or 45000 (the old defaults) is moved to the new default once; any other value you chose is kept |
| My far distance on the client was 1000 m | SEEN (my own default) | Default **3000 m**, adjustable to 10000 m |
| ACF kills a bullet's client effect once the bullet is more than 16380 units from the **centre of your chunk**. AP impacts, penetrations and ricochets are made on the client from that bullet record, so a shell that left that box could not show its impact when the hit message arrived | SEEN (`effects/acf_bullet_effect.lua`, `ballistics_cl.lua`, `ammo_types/ap.lua`) | The bullet is kept alive and simulated past that limit. Inside the limit ACF's own movement code runs unchanged |
| The engine places and draws effects and particles only inside about +-16384 units of the frame origin, which under InfMap is the **centre of your chunk, not you** | GUESS (high). InfMap's own source says "when bounding box is outside of world bounds the object isn't rendered" (`cl_inf_chunks.lua`) and the GMod wiki gives the same limit for an effect origin | See "Far effects" below |

### Far effects (replaces the stand-ins)

When an effect's position is outside the placeable area, ACF's real effect code still runs (`acf_explosion.lua`, `acf_penetration.lua`, `acf_smoke.lua` and so on), with its real random numbers, counts, sizes, colours and materials. While it runs, `ParticleEmitter` is replaced by a recorder that keeps every particle with every setting ACF gives it. Each frame this addon moves the particles (velocity, gravity, air resistance, roll) and draws them with `render.DrawQuadEasy` / `render.DrawBeam`. Those are immediate-mode draw calls, so the engine's box does not apply to them (this is also how InfMap draws its own terrain). A particle farther than 12000 units from your eye is drawn on the same line of sight at 12000 units, with its size shrunk by the same factor, which is the same picture on screen.

- Decals are switched off while a far effect runs: its surface trace would land on the wrong surface.
- If the engine turns out to clamp the effect's origin to its limit, the recorded particles are detected sitting at the clamped point and are moved back to the real position (`ReplayCorrected` in `acf_infmap_status`). So the design does not depend on my guess about that.
- Engine-only effects (the `cball_explode` that ACF's impact effect creates) have no Lua code to run. They get a small generic puff and spark burst. **That look is mine, not ACF's.**
- A far tracer is the same sprite ACF adds each tick, replayed. The two faint smoke puffs (alpha 10) are left out because they cannot be seen at range.

What is **not** the same as a near effect: a far effect is not hidden by terrain between you and it (it is drawn closer than it is), effects that draw a model or their own shape (the explosion's refraction sphere) show nothing far away, and a far impact's sound is placed by ACF at the end of its trace, which is not at the impact.

### The bullet that is not visible

**I did not find the cause by reading source, and I am not going to pretend otherwise.** What I checked piece by piece (SEEN in ACF and InfMap source, and run against ACF's real `acf_bullet_effect.lua` in the harness): the server message, the receiver, the crate lookup, `util.Effect`, `Init`, `ApplyMovement`, `Think`, `Render`. All of it works in the harness. The only difference between the harness and the game is what the engine does with a Lua effect, and I cannot see that from here.

So instead of a fix that hides the question, version 4 **measures it**:

- It counts how often the engine really calls the bullet effect's `Render` (`renders=` in `acf_infmap_bulletdebug`).
- If a bullet inside the placeable area gets no `Render` call in 3 frames, it says so once in the console and draws the model itself from ACF's own simulation state (model path, position, direction and scale from ACF's own data). The status line shows how many bullets needed that.
- `acf_infmap_bullettest` creates a slow test shell 300 units in front of you through ACF's real effect, without a gun, the server or the network, and prints whether ACF's `Init` accepted it and how many times the engine drew it. That cuts the problem in half in one command.
- Whatever refuses a bullet is reported with its reason (crate unknown to the client, or ACF's `Init` gave up).

If you still see nothing after this, the numbers from those commands say which half is broken (see "Your next session").

GUESS: if the engine ignores a per-instance `Render` function, the counter stays 0 even though the engine does draw the model; the addon then draws a second copy in the same place, which looks the same. The status line says so.

## What it fixes (all versions)

| Area | Problem under InfMap | Fix |
|---|---|---|
| Sounds | ACF picks who hears a sound with `net.SendPAS(GetPos())`, and InfMap's server `GetPos()` is a global position. Engines in other chunks are silent or heard in the wrong place. | Sounds go to every player within a range (global distance), loops are created for players who drive into range and stopped for players who leave. Client plays one-shots of other-chunk entities at their local-frame position. |
| Bullet traces | A trace only sees entities in the chunk it starts in. A shot that crosses a border can tunnel through a prop right behind it. | While `ACF.trace` runs, the line is cut at chunk borders and each piece is traced in its own chunk. First hit wins. |
| Clone hits | A hit on an `infmap_clone` names the clone, not the prop. ACF then treats the hit as World, so the prop takes no damage. | The clone hit is turned into a hit on the real prop. If the real prop is on the bullet's filter (your own gun), the clone is ignored and the shot continues. |
| Stray bullets | Nothing removes a bullet that hits nothing, so misses pile up in ACF's 2000 bullet slots and guns stop firing. | A bullet older than `acf_infmap_bullet_lifetime` seconds (default 180) is removed with ACF's own `RemoveBullet`. |
| Effects | Tracers, muzzle flashes, impacts and explosions carry a global position that the effect system cannot store, and the engine picks the audience from that position. | Server effects go out in this addon's own message with the exact position; the client converts it into its own chunk frame and calls `util.Effect` itself, so ACF's own effect code runs on an ordinary local position. **New:** a `util.Effect` call that names an ACF effect (the missile code does `util.Effect("ACF_Explosion")`) goes the same way. Effects of other addons are untouched. |
| Tracer crate | ACF's tracer effect finds its ammo crate with `Data:GetEntity()`. The server sends the crate as a number, and `SetEntIndex` / `GetEntIndex` are server-only (GMod wiki), so a client-made effect cannot carry it. | The client sets the entity itself. `EntityFixed` counts the times it was needed. |
| Far effects and bullets | See above. | See above. |

## Install

1. Delete any older `acf_infmap_compat` folder (versions 1 to 3 used the same name).
2. If you installed the "ACF InfMap sound glue" (the `infmap_sounds_sv.lua` / `infmap_sounds_cl.lua` files inside ACF's `lua/acf/compatibility/`), delete those two files. If you leave them, this addon notices, prints a warning and turns its own sound fix off so nothing is done twice.
3. Put the `acf_infmap_compat` folder in `garrysmod/addons/` on the **server** (listen server: your own addons folder).
4. Restart the map. Clients get the client files automatically (the autorun calls `AddCSLuaFile`).

Load order: GMod runs autorun files alphabetically, and `zz_` sorts after InfMap's `!!inf_init` and ACF's loader (KNOWN). After every `acf_reload` the addon re-wraps ACF through ACF's own `ACF_OnLoadAddon` hook (SEEN in ACF's loader; also exercised with ACF's real loader in the harness).

## Settings

The menu (Spawn menu, Utilities, ACF InfMap, Settings) shows all of these. **Your settings** are saved on your computer. **Server settings** are changed by a superadmin (the menu sends the change to the server, which checks who sent it and clamps the value); everyone else sees them read-only. Every one is also a plain console variable. 1 metre = 39.37 units; a chunk is 20000 units (508 m).

| Name | Where | Default | Meaning |
|---|---|---|---|
| `acf_infmap_cl_replay` | you | 1 | 1 = show effects the engine cannot place (replayed from ACF's own effect code). 0 = drop them |
| `acf_infmap_cl_replay_distance` | you | 3000 | Metres. Far effects and far tracers are shown up to this distance from you (0 to 10000) |
| `acf_infmap_cl_replay_scale` | you | 1 | Size multiplier of far particles (0.1 to 5) |
| `acf_infmap_cl_bullets` | you | 1 | 1 = keep bullets alive past the engine's limit and draw their tracers there. 0 = stock |
| `acf_infmap_cl_bullet_draw` | you | 1 | 1 = draw a bullet's model yourself when the engine never does |
| `acf_infmap_verbose` | you | 0 | 1 = print a line for every ACF effect this client receives |
| `acf_infmap_effect_range` | server | 120000 | Units (global distance) within which players are sent an effect. Keep it at least your far distance (3000 m = 118110 units) |
| `acf_infmap_fix_effects` | server | 1 | 0 = stock effect path |
| `acf_infmap_sound_range` | server | 20000 | Units within which players receive ACF sounds |
| `acf_infmap_fix_sounds` | server | 1 | 0 = stock ACF sound routing |
| `acf_infmap_fix_traces` | server | 1 | 0 = stock `ACF.trace` |
| `acf_infmap_bullet_lifetime` | server | 180 | Seconds a bullet may fly; 0 = never remove (stock) |

Each fix has its own switch, so a misbehaving session can be bisected: turn one off, repeat the test.

## Commands

| Where | Command | Shows |
|---|---|---|
| server + client | `acf_infmap_status` | Which functions are wrapped, counters, settings, bullets in flight, far-effect and bullet state |
| client | `acf_infmap_bullettest [metres]` | A slow test shell through ACF's real bullet effect (a tracer crate near you is used when there is one). Prints whether ACF's `Init` accepted it, then after 1 s how often the engine drew it |
| client | `acf_infmap_bulletdebug` | The last 12 bullet effects this client received (index, hit type, position, whether the crate was valid before and after the fix, whether ACF created the bullet) and every bullet it is simulating (position, drawn by the engine, number of engine renders, far, age) |
| client | `acf_infmap_fartest [metres]` | A real ACF explosion that far ahead of you (default 1500). Tells you whether it was replayed, was an ordinary engine effect, or was out of range |
| client | `acf_infmap_replaydebug` | How many far particles are live and have been recorded, how many effects were empty, dropped or raised errors, and the first 10 live particles |
| server (superadmin) | `acf_infmap_sounddebug` | Per player: chunk, global position. Per engine/turret/waterjet: how many players stock ACF would have sent to vs how many this addon sends to |
| client | `acf_infmap_sounddebug_cl` | Your chunk, each engine's chunk, local position, distance, and whether its loop is playing |
| server (superadmin, from your own console) | `acf_infmap_tracedebug [distance]` | Fires a line from your eyes through **stock** `ACF.trace` and through the **fixed** one and prints both results. Default distance 30000 |

## Your next session (about 10 minutes)

1. **Is it running?** Server and client console: `acf_infmap_status`. Look for `wrapped` lines, no "failed" lines, and on the client `far effects:` and `bullets:` lines.
2. **The bullet, with no gun involved.** Client console: `acf_infmap_bullettest`. A small shell should float away from you for about 4 seconds. Then tell me which of these happened:
   - you see it, and the console says `Init ran inside util.Effect: yes`: ACF's own bullet effect draws fine here. The problem is between the server and the client. Fire a real round and run `acf_infmap_bulletdebug`;
   - you see it only because the console says the addon drew it (`engine called Render 0 time(s)` plus a warning): the engine does not draw ACF's Lua effect here. That is the root cause, and the addon now draws around it;
   - you do not see it and the console says `Init ran inside util.Effect: NO`: ACF's `Init` refused. Paste the output of `acf_infmap_status`;
   - you do not see it, `Init` says yes, `Render` count is above 0: the engine draws it but it is invisible (material or model problem). Paste the output.
3. **A real bullet.** Fire tracer ammo in your own chunk, then `acf_infmap_bulletdebug`. A line per shot with `crate-valid-before-fix=NO after=yes` means the crate fix is working; `created=NO` means ACF refused the bullet (the console says why); no line at all means the client never got the message (check the server's `EffectsSent`).
4. **Far effects.** `acf_infmap_fartest 1500`. A real ACF explosion (fireball, smoke, debris) should appear 1500 m ahead. The text it prints tells you what it did. If nothing shows and it says "replayed", the engine did not draw my immediate-mode particles: tell me, that is the one thing in this design I cannot check from here.
5. **Three chunks.** Shoot something 1100 to 1500 m away (three chunks is 1524 m). AP rounds should show their impact when the shell lands; HE should show its explosion. Raise `acf_infmap_cl_replay_scale` if the far particles look too small.
6. **Close effects.** The same hit near you should look exactly like stock ACF (native effect, decal, sound).
7. **Sounds, traces, stray bullets.** As in version 2 (sounds across chunks, `acf_infmap_tracedebug 30000` across a border, fire at the sky and watch `Killed`).
8. **ACF lasers.** If your laser mod calls `ACF.trace` it already gets the chunk-aware version. If it calls `util.TraceLine` directly, switch to `ACFInfMapCompat.TraceLine(Data)` (same arguments, same result table). Send me the mod.

## What was tested, and how

`tools/test_acf_infmap_compat.lua` (a test script that stays in my workspace and is not in this zip) runs this addon's real files together with ACF's real `traces_sh.lua`, `trace_workaround.lua`, `ballistics_sv.lua`, `ballistics_cl.lua`, `sounds_sv.lua`, `sounds_cl.lua`, `effects_sh.lua`, the effect classes **`acf_bullet_effect.lua`, `acf_explosion.lua` and `acf_impact.lua`** and ACF's real `gloader.lua` against a mock of the GMod API. The mock includes a line-for-line port of InfMap's `modify_trace_data` (including the `REFERENCE_DATA` bug), float32 vector rounding, typed net messages (a write/read mismatch fails the test), a client `EffectData` whose `GetEntity` does **not** follow `SetEntIndex` (the suspected engine behaviour), and an optional engine that clamps effect origins to 16384.

Result: **292 checks pass.** I also broke the addon on purpose 53 different ways (for example: stop copying the crate, never keep a bullet alive, draw the model twice, forget to restore `ParticleEmitter`, write the wrong migrated value) and ran the checks against each broken copy. All 53 broken copies were caught by at least one check, so the checks are not decorative.

What that proves: the logic does what the headers say against ACF's real code, messages round-trip, ACF's real explosion code runs through the recorder without errors, reload and repeated install are safe. What it cannot prove: that real GMod and real InfMap behave the way the mock assumes, and nothing about how anything looks.

## GUESS list (confirm in game)

1. That the engine does not place or draw effects and particles outside +-16384 of the chunk centre. If it does, you lose nothing (the replay is only used outside the placeable area).
2. That `render.DrawQuadEasy` / `render.DrawBeam` draw at the shortened positions (within 12000 units of the eye). They are immediate-mode calls; InfMap's own terrain drawing relies on the same thing. `acf_infmap_fartest` shows it in five seconds.
3. The particle physics. GMod's exact air-resistance formula is not documented; `DragRate` (0.015) in `cl_replay.lua` is my guess. Sprites, sizes, colours, counts and timing are ACF's own, so only how far a puff drifts can differ.
4. That a particle created with a negative life time is not drawn until it is born, and that a stretched sprite is drawn from its position back along its direction.
5. That ACF's `Init` runs inside `util.Effect` (the test command checks it and prints the answer).
6. That the engine calls a per-instance `Render` function (see above for what happens if it does not).
7. That a client-made `CEffectData` does not resolve `SetEntIndex` into `GetEntity`. `acf_infmap_bulletdebug` answers it directly.
8. That a model on the client can be drawn through `ClientsideModel` plus `DrawModel` in `PostDrawOpaqueRenderables` under InfMap.
9. The Workshop InfMap equals the GitHub source I read.
10. Who stock `net.SendPAS` reaches for a point outside the real map. The sound fix does not depend on the answer; `acf_infmap_sounddebug` prints it.
11. A hit on a clone really has no `CPPIGetOwner`, which is why ACF handles it as a World hit. (Damage across borders already works for you, so the swap is doing its job.)
12. A trace given an `output` table fills and returns that same table. The addon copies the result when it is not, and counts `OutputCopied`.
13. After a border crossing, tracer and impact visuals look right (the client frame shift).
14. 180 s is a good bullet lifetime. High lobbed shells (almost vertical, 1500 m/s) take about 197 s without drag.
15. `FCVAR_ARCHIVE` + `FCVAR_REPLICATED` together behave on your server (saved on the server, readable by clients).
16. That the materials ACF names (`sprites/acf_tracer.vmt`, `particle/smokesprites_000N`, `effects/muzzleflash*`, `particles/flamelet*`) can be loaded with `Material()` at draw time exactly as `ParticleEmitter:Add` loads them. The `.vmt` ending is removed first.

## Not covered (SEEN unless marked)

- **Bullets fired from farther than `acf_infmap_effect_range` away** (about 3 km by default) are never sent to you, and a hit from such a bullet shows no impact (the impact needs the tracer's record). Raise the effect range if you need it.
- **Far impact sounds** are played where ACF's trace ends, not at the impact.
- **Far effects with a model or their own shape** (the explosion's refraction sphere) are not shown. Muzzle flashes use the gun entity, not a position, so they are not routed.
- **Far particles are not hidden by terrain** between you and them.
- **ACF code that copies `ACF.trace` into a local variable when it loads** keeps calling the stock function: explosion line-of-sight (`damage/explosion_sv.lua`), missile sensors (`receivers.lua`), optical fuzes, radio and laser guidance, the radar.
- **Explosion and burn damage across chunks**: InfMap itself cancels it with an `EntityTakeDamage` hook. Not touched.
- **Client-side traces** (the client's own `util.TraceLine` calls) are not touched. ACF's impact effect traces from the hit point to find the surface for decals; that trace is InfMap's own client trace, which only sees things in your chunk. Decals are not made for far effects.
- **`ScreenShake`**, sounds that the server emits itself, and anything outside ACF.
- A piece of a shot that starts so far from the origin that the next chunk cannot be told apart in float32 (beyond about chunk 100000) may skip a sliver of up to 128 units at the border.

## Files

```
lua/autorun/zz_acf_infmap_compat.lua   entry point, install + reload hooks
lua/acf_infmap_compat/sh_core.lua      wrap helper, counters, settings list, status command
lua/acf_infmap_compat/sv_sounds.lua    server sound routing + loop tracking
lua/acf_infmap_compat/cl_sounds.lua    client one-shots for other-chunk entities
lua/acf_infmap_compat/sv_traces.lua    chunk-aware ACF.trace + clone resolution + tracedebug
lua/acf_infmap_compat/sv_bullets.lua   stray bullet cap
lua/acf_infmap_compat/sv_effects.lua   effect messages with exact positions (CreateEffect and direct util.Effect of ACF effects)
lua/acf_infmap_compat/sv_settings.lua  server side of the menu (superadmin-only setter)
lua/acf_infmap_compat/cl_effects.lua   effect receiver, crate fix, tracer frame shift, bulletdebug
lua/acf_infmap_compat/cl_replay.lua    far effects: records ACF's effect particles and draws them, fartest, replaydebug
lua/acf_infmap_compat/cl_bullets.lua   keep-alive, far tracers, render counter, own model drawing, bullettest
lua/acf_infmap_compat/cl_menu.lua      the settings panel
```
