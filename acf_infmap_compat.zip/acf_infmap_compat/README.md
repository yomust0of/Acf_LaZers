# ACF3 <-> InfMap compatibility (standalone addon), version 3

One addon folder. It edits neither ACF nor InfMap: it wraps ACF's own functions at runtime, keeps the originals, and does nothing on maps that are not InfMap maps. Delete the folder and you are back to stock behaviour.

Built for the **original InfMap** (meetric1's "Infinite Map Base", the Workshop one, `chunk_size = 10000`) and ACF-3 master.

Labels used everywhere (here and in the headers of every `.lua` file):

- **SEEN** = read in the ACF / InfMap source, or exercised against ACF's real files in the test harness.
- **KNOWN** = standard GMod / Source behaviour that I did not re-check.
- **GUESS** = inference. Only a real game can confirm it.

## What changed in version 3 (after your first live test)

Your report: damage works, hit effects work across borders, but **tracers and the bullet model do not render, and hit effects stop showing at a short distance.**

| Report | What I found | What version 3 does | Confidence |
|---|---|---|---|
| Tracer and bullet model missing, even in your own chunk | ACF's tracer effect finds the ammo crate with `Data:GetEntity()` and gives up without it. The server sends the crate as a number (`EntIndex`). The addon rebuilds every effect on the client, and on a client-made effect nothing converts that number into an entity. | The client now sets the entity itself. `acf_infmap_status` counts `EntityFixed` (times it was needed) and `EntityMissing` (crate unknown to the client). | **GUESS.** The source shows the dependency (SEEN). That the engine does not do the conversion on a client-made effect is a guess. If `EntityFixed` stays 0 and tracers are still missing, this was not the cause and `acf_infmap_bulletdebug` will show where it breaks. |
| Hit effects stop at a short, seemingly random distance | The engine only draws inside +-16384 units of the **centre of your chunk**, not of you. ACF kills a bullet's client effect when the bullet leaves that box, and a bullet effect that is gone cannot show its impact. Version 2 also dropped any effect outside it. | Bullets that leave the box are kept alive (simulated, not drawn). Effects and tracers outside the box are drawn as simple stand-ins (a flash and smoke puff, a streak) at a shortened distance along the same line of sight, up to `acf_infmap_cl_far_distance` metres (default 1000). | SEEN for the cause (acf_bullet_effect.lua, ballistics_cl.lua) and the mock. **GUESS** for how the stand-ins look and for the engine not drawing outside the box. |
| "Make it configurable in the menu" | | A settings panel: **Spawn menu, Utilities tab, ACF InfMap, Settings**. | GUESS: the layout (the harness has no UI; the code paths that decide values are tested). |

Also: the effect range default went from 30000 to **45000 units (about 1.1 km)**, so the server actually sends effects to a player 1 km away. 1 metre = 39.37 units. If your saved value is exactly 30000 (the old default) it is moved to 45000 once; any other value you chose is kept.

## What it fixes (all versions)

| Area | Problem under InfMap | Fix |
|---|---|---|
| Sounds | ACF picks who hears a sound with `net.SendPAS(GetPos())`, and InfMap's server `GetPos()` is a global position. Engines in other chunks are silent or heard in the wrong place. | Sounds go to every player within a range (global distance), loops are created for players who drive into range and stopped for players who leave. Client plays one-shots of other-chunk entities at their local-frame position. |
| Bullet traces | A trace only sees entities in the chunk it starts in. A shot that crosses a border can tunnel through a prop right behind it. | While `ACF.trace` runs, the line is cut at chunk borders and each piece is traced in its own chunk. First hit wins. |
| Clone hits | A hit on an `infmap_clone` names the clone, not the prop. ACF then treats the hit as World, so the prop takes no damage. | The clone hit is turned into a hit on the real prop. If the real prop is on the bullet's filter (your own gun), the clone is ignored and the shot continues. |
| Stray bullets | Nothing removes a bullet that hits nothing, so misses pile up in ACF's 2000 bullet slots and guns stop firing. | A bullet older than `acf_infmap_bullet_lifetime` seconds (default 180) is removed with ACF's own `RemoveBullet`. |
| Effects | Tracers, muzzle flashes, impacts and explosions carry a global position that the effect system cannot store, and the engine picks the audience from that position. | Server effects go out in this addon's own message with the exact position; the client converts it into its own chunk frame and calls `util.Effect` itself, so ACF's own effect code runs unchanged inside the drawable box. Tracers are shifted when you cross a chunk border. |
| Far effects (new) | See the table above. | See the table above. |

## Install

1. Delete any older `acf_infmap_compat` folder (versions 1 and 2 used the same name).
2. If you installed the "ACF InfMap sound glue" (the `infmap_sounds_sv.lua` / `infmap_sounds_cl.lua` files inside ACF's `lua/acf/compatibility/`), delete those two files. If you leave them, this addon notices, prints a warning and turns its own sound fix off so nothing is done twice.
3. Put the `acf_infmap_compat` folder in `garrysmod/addons/` on the **server** (listen server: your own addons folder).
4. Restart the map. Clients get the client files automatically (the autorun calls `AddCSLuaFile`).

Load order: GMod runs autorun files alphabetically, and `zz_` sorts after InfMap's `!!inf_init` and ACF's loader (KNOWN). After every `acf_reload` the addon re-wraps ACF through ACF's own `ACF_OnLoadAddon` hook (SEEN in ACF's loader; also exercised with ACF's real loader in the harness).

## Settings

The menu (Spawn menu, Utilities, ACF InfMap, Settings) shows all of these. **Your settings** are saved on your computer. **Server settings** are changed by a superadmin (the menu sends the change to the server, which checks who sent it and clamps the value); everyone else sees them read-only. Every one is also a plain console variable.

| Name | Where | Default | Meaning |
|---|---|---|---|
| `acf_infmap_cl_far_effects` | you | 1 | 1 = draw stand-ins for effects the engine cannot place. 0 = drop them |
| `acf_infmap_cl_far_distance` | you | 1000 | Metres. Stand-ins and far tracers are drawn up to this distance from you (0 to 5000) |
| `acf_infmap_cl_far_scale` | you | 1 | Size multiplier of the stand-ins (0.1 to 5) |
| `acf_infmap_effect_range` | server | 45000 | Units (global distance) within which players are sent an effect. Keep it at least your far distance (1000 m = 39370 units) |
| `acf_infmap_fix_effects` | server | 1 | 0 = stock effect path |
| `acf_infmap_sound_range` | server | 20000 | Units within which players receive ACF sounds |
| `acf_infmap_fix_sounds` | server | 1 | 0 = stock ACF sound routing |
| `acf_infmap_fix_traces` | server | 1 | 0 = stock `ACF.trace` |
| `acf_infmap_bullet_lifetime` | server | 180 | Seconds a bullet may fly; 0 = never remove (stock) |

Each fix has its own switch, so a misbehaving session can be bisected: turn one off, repeat the test.

## Commands

| Where | Command | Shows |
|---|---|---|
| server + client | `acf_infmap_status` | Which functions are wrapped, counters (server: `Swapped`, `Skipped`, `Split`, `OutputCopied`, `Killed`, `EffectsSent`; client: `EffectsShown`, `EffectsDropped`, `EntityFixed`, `EntityMissing`, `BulletsKeptAlive`, `FarShown`, `FarDropped`), settings, bullets in flight |
| client | `acf_infmap_bulletdebug` | The last 12 bullet effects this client received (index, hit type, position, whether the crate was valid before and after the fix), and every bullet it is simulating right now (position, inside the drawable box, drawn natively, far) |
| client | `acf_infmap_fartest [metres]` | Puts a fireball stand-in that far ahead of you (default 600), so far drawing can be checked without shooting |
| server (superadmin) | `acf_infmap_sounddebug` | Per player: chunk, global position. Per engine/turret/waterjet: how many players stock ACF would have sent to vs how many this addon sends to |
| client | `acf_infmap_sounddebug_cl` | Your chunk, each engine's chunk, local position, distance, and whether its loop is playing |
| server (superadmin, from your own console) | `acf_infmap_tracedebug [distance]` | Fires a line from your eyes through **stock** `ACF.trace` and through the **fixed** one and prints both results. Default distance 30000 |

## Your next session (about 10 minutes)

1. **Is it running?** Server and client console: `acf_infmap_status`. Look for `wrapped` lines, no "failed" lines, and on the client a `far effects:` line. Paste both if anything is off.
2. **Tracers.** Use ammo with the tracer option on. Fire in your own chunk. Then `acf_infmap_bulletdebug` on the client:
   - a line per shot with `crate-valid-before-fix=NO after=yes` means the diagnosis was right and the fix is working;
   - `before=yes` means the engine already resolved it (the cause is elsewhere);
   - `after=NO` means the client does not know the crate entity;
   - no line at all means the client never got the message (check the server's `EffectsSent`).
3. **Far drawing.** `acf_infmap_fartest 800`: a fireball and smoke should appear 800 m ahead. If you see nothing, say so and run `acf_infmap_status` (the `far effects:` line).
4. **Real distance.** Shoot something 500 to 900 m away (outside the +-16384 box if you stand near your chunk's edge). Expect: a streak for tracer rounds while it flies, then a flash and puff at the hit. Raise `acf_infmap_cl_far_scale` if they are too small to see.
5. **Close effects.** The same hit near you should look exactly like stock ACF (native effect, decal, sound).
6. **Sounds, traces, stray bullets.** As in version 2 (sounds across chunks, `acf_infmap_tracedebug 30000` across a border, fire at the sky and watch `Killed`).
7. **ACF lasers.** If your laser mod calls `ACF.trace` it already gets the chunk-aware version. If it calls `util.TraceLine` directly, switch to `ACFInfMapCompat.TraceLine(Data)` (same arguments, same result table). Send me the mod.

## What was tested, and how

`tools/test_acf_infmap_compat.lua` (a test script that stays in my workspace and is not in this zip) runs this addon's real files together with ACF's real `traces_sh.lua`, `trace_workaround.lua`, `ballistics_sv.lua`, `ballistics_cl.lua`, `sounds_sv.lua`, `sounds_cl.lua`, `effects_sh.lua`, **`effects/acf_bullet_effect.lua`** and ACF's real `gloader.lua` against a mock of the GMod API. The mock includes a line-for-line port of InfMap's `modify_trace_data` (including the `REFERENCE_DATA` bug), float32 vector rounding, typed net messages (a write/read mismatch fails the test), and a client `EffectData` whose `GetEntity` does **not** follow `SetEntIndex` (the suspected engine behaviour).

223 checks pass, and 37 deliberate breakages of the addon (clone swap removed, crate not resolved, bullets killed outside the box, stand-ins not shortened, admin check removed, and so on) are each caught by at least one check. The same scenario without the addon is also run, and shows stock ACF killing the bullet effect at x > 16380.

What that proves: the logic does what the headers say against ACF's real code, messages round-trip, reload and repeated install are safe. What it cannot prove: that real GMod and real InfMap behave the way the mock assumes, and nothing about how the stand-ins look.

## GUESS list (confirm in game)

1. That a client-made `CEffectData` does not resolve `SetEntIndex` into `GetEntity` (the tracer cause). `acf_infmap_bulletdebug` answers it directly.
2. That the engine does not draw particles or effects outside +-16384 of the chunk centre. If it does, you lose nothing (stand-ins are only used outside).
3. How the stand-ins look: sizes, colours, lifetimes are eyeballed. A stand-in is not hidden by terrain between you and it (it is drawn at a shortened distance, in front of that terrain).
4. That the Lua effect's `Render` override and `SetNoDraw` hide the model while a bullet is outside the box. If a ghost model stays at the border, tell me.
5. That the materials `sprites/light_glow02_add`, `particle/smokesprites_0003` and `effects/laser1` exist and look acceptable.
6. Who stock `net.SendPAS` reaches for a point outside the real map. The sound fix does not depend on the answer; `acf_infmap_sounddebug` prints it.
7. A hit on a clone really has no `CPPIGetOwner`, which is why ACF handles it as a World hit. (Damage across borders already works for you, so the swap is doing its job.)
8. A trace given an `output` table fills and returns that same table. The addon copies the result when it is not, and counts `OutputCopied`.
9. The Workshop InfMap equals the GitHub source I read.
10. After a border crossing, tracer and impact visuals look right (the client frame shift).
11. 180 s is a good bullet lifetime. High lobbed shells (almost vertical, 1500 m/s) take about 197 s without drag.
12. `FCVAR_ARCHIVE` + `FCVAR_REPLICATED` together behave on your server (saved on the server, readable by clients).

## Not covered (SEEN unless marked)

- **Bullets fired from farther than `acf_infmap_effect_range` away** (about 1.1 km by default) are never sent to you, so their tracer does not exist for you, and a hit near you from such a bullet shows no impact (the impact needs the tracer's record). Raise the effect range if you need it.
- **Stand-ins are simple.** No decals, no sounds, no debris, no per-ammo look (HEAT jets, smoke colour shapes). Inside the box you get ACF's own effects.
- **Muzzle flashes** use the gun entity, not a position, so they are not routed to stand-ins.
- **ACF code that copies `ACF.trace` into a local variable when it loads** keeps calling the stock function: explosion line-of-sight (`damage/explosion_sv.lua`), missile sensors (`receivers.lua`), optical fuzes, radio and laser guidance, the radar.
- **Explosion and burn damage across chunks**: InfMap itself cancels it with an `EntityTakeDamage` hook. Not touched.
- **`util.Effect("ACF_Explosion")` called directly by `acf_missile`** is not routed (`init.lua` line 772).
- **Client-side traces** (the client's own `util.TraceLine` calls) are not touched. ACF's impact effect traces from the hit point to find the surface for decals; that trace is InfMap's own client trace, which only sees things in your chunk.
- **`ScreenShake`**, sounds that the server emits itself, and anything outside ACF.
- A piece of a shot that starts so far from the origin that the next chunk cannot be told apart in float32 (beyond about chunk 100000) may skip a sliver of up to 128 units at the border.

## Files

```
lua/autorun/zz_acf_infmap_compat.lua   entry point, install + reload hooks
lua/acf_infmap_compat/sh_core.lua      wrap helper, counters, settings list, status command
lua/acf_infmap_compat/sv_sounds.lua    server sound routing + loop tracking
lua/acf_infmap_compat/cl_sounds.lua    client one-shots for other-chunk entities
lua/acf_infmap_compat/sv_traces.lua    chunk-aware ACF.trace + clone resolution + tracedebug
lua/acf_infmap_compat/sv_bullets.lua   stray bullet cap
lua/acf_infmap_compat/sv_effects.lua   effect messages with exact positions
lua/acf_infmap_compat/sv_settings.lua  server side of the menu (superadmin-only setter)
lua/acf_infmap_compat/cl_effects.lua   effect receiver, crate fix, tracer frame shift, bulletdebug
lua/acf_infmap_compat/cl_far.lua       keep-alive, far stand-ins, far tracer streaks, fartest
lua/acf_infmap_compat/cl_menu.lua      the settings panel
```
