-- ACF effects (client half): receives the message from sv_effects.lua and creates the effect in the local player's frame.
--
-- What it does:
--   1. Converts the effect's global Origin into the local player's chunk frame (Origin - chunk * 20000, in doubles).
--   2. An Origin inside the placeable window (Compat.Window, 16000 units from the frame origin) becomes a normal util.Effect, so
--      ACF's own effect code runs on an ordinary local position. An Origin outside it goes to cl_far.lua, which draws a simple
--      stand-in (or drops it when stand-ins are off or it is too far). `EffectsDropped` counts the ones nobody could show.
--   3. Resolves EntIndex to a real entity (see FixEntity): this is what makes ACF's bullet / tracer effect work.
--   4. When the local player crosses into another chunk, moves every tracer ACF is simulating (and every stand-in) by one chunk,
--      so nothing jumps.
--
-- Evidence labels: SEEN = read in source / run in the mock, KNOWN = standard GMod behaviour not re-checked, GUESS = needs a game.
--   SEEN:  client Entity:GetPos() is relative to the local player's chunk, and the player's chunk is LocalPlayer().CHUNK_OFFSET
--          (infmap/cl_inf_detours.lua, cl_inf_chunks.lua)
--   SEEN:  ACF's tracer effect (effects/acf_bullet_effect.lua) finds the ammo crate with Data:GetEntity() and gives up (no tracer,
--          no model, and the later hit message finds nothing to update, so no impact either) when that entity is not valid.
--          The server sets the crate as `EntIndex` (a number: ballistics_sv.lua line 36, `Bullet.Crate = Entity:EntIndex()`).
--   GUESS: that on a CLIENT-made CEffectData, SetEntIndex does not resolve to an entity that GetEntity returns. (Over the network
--          the engine does that conversion; I know of no documentation that says the client-side setter does.) FixEntity sets the
--          entity explicitly, so it works either way, and `EntityFixed` counts the times it was needed: if that counter stays 0
--          while tracers still fail, this was not the cause.
--   SEEN:  ACF simulates every tracer on the client from the Origin it was sent, in ACF.BulletEffect[Index].SimPos
--          (ballistics_cl.lua, effects/acf_bullet_effect.lua)
--   SEEN:  chunk-to-chunk frame shift is Full = 2 * InfMap.chunk_size per chunk, from InfMap.unlocalize_vector
--   KNOWN: util.Effect called on the client creates the effect locally.
--   GUESS: that LocalPlayer().CHUNK_OFFSET is already updated on the client at the moment this message arrives after a chunk
--          change. If it lags by a tick, effects created in that tick are off by one chunk, visibly only while crossing.
--   GUESS: that moving the particle emitter with SetPos is harmless. (Particles are added with absolute positions.)

local Compat = ACFInfMapCompat
local Stats  = Compat.Stats
local Tag    = Compat.EffectTag
local Fields = Compat.EffectFields

-- Effects that must always be created, whatever their position (see the receiver)
local SelfManaged = {acf_bullet_effect = true}

local function ReadValue(Kind, Field)
	if Kind == Tag.Number then
		return net.ReadDouble()
	elseif Kind == Tag.Vector then
		local X, Y, Z = net.ReadDouble(), net.ReadDouble(), net.ReadDouble()

		-- Origin stays three plain numbers until it has been converted, because a Vector holds 32-bit floats
		if Field == "Origin" then return {X, Y, Z} end

		return Vector(X, Y, Z)
	elseif Kind == Tag.Angle then
		return Angle(net.ReadFloat(), net.ReadFloat(), net.ReadFloat())
	elseif Kind == Tag.Entity then
		return net.ReadEntity()
	end

	return net.ReadBool()
end

--- Converts a global position (three numbers) into the local player's frame.
--- @return Vector # the local-frame position
--- @return boolean # whether it is inside the window where native effects can be placed
local function ToLocalFrame(Global)
	local _, Full = Compat.ChunkSizes()
	local Player  = LocalPlayer()
	local Offset  = IsValid(Player) and Player.CHUNK_OFFSET or nil
	local X, Y, Z = Global[1], Global[2], Global[3]

	if Offset then
		X, Y, Z = X - Offset.x * Full, Y - Offset.y * Full, Z - Offset.z * Full
	end

	local Local = Vector(X, Y, Z)

	return Local, Compat.InWindow(Local)
end

Compat.ToLocalFrame = ToLocalFrame

--- Makes sure the effect's entity is the real entity. A server effect carries the entity as an index (`EntIndex`); ACF's tracer
--- effect reads it back with Data:GetEntity(), so the entity has to be set explicitly on a client-made EffectData.
--- @return boolean? # whether GetEntity already returned a valid entity before the fix (nil: the effect has no EntIndex)
--- @return boolean? # whether it does now
local function FixEntity(Effect, Values)
	local Index = Values.EntIndex

	if not isnumber(Index) or Index <= 0 then return end

	local Has = false

	if Effect.GetEntity then
		local OK, Ent = pcall(Effect.GetEntity, Effect)

		Has = OK and IsValid(Ent)
	end

	if Has then return true, true end

	local Ent = Entity(Index)

	if IsValid(Ent) then
		Effect:SetEntity(Ent)
		Stats.EntityFixed = Stats.EntityFixed + 1

		return false, true
	end

	Stats.EntityMissing = Stats.EntityMissing + 1 -- the client does not know that entity (yet): nothing can be done here

	return false, false
end

Compat.FixEntity = FixEntity

-- The last few bullet effects this client received, for `acf_infmap_bulletdebug`. Lives on the addon table.
Compat.BulletLog = Compat.BulletLog or {}

local LogSize = 12

local function LogBullet(Name, Values, Inside, Before, After)
	local Log = Compat.BulletLog

	Log[#Log + 1] = {
		Time = CurTime(), Name = Name, Index = Values.DamageType, Hit = Values.Scale, Attachment = Values.Attachment, Origin = Values.Origin,
		Inside = Inside, EntIndex = Values.EntIndex, Before = Before, After = After,
	}

	if #Log > LogSize then table.remove(Log, 1) end
end

net.Receive("ACFInfMapCompat_Effect", function()
	local Name   = net.ReadString()
	local Allow  = net.ReadBool()
	local Ignore = net.ReadBool()
	local Values = {}

	-- Read the whole message first, so a dropped effect never leaves unread bytes behind
	for _ = 1, net.ReadUInt(5) do
		local Field = Fields[net.ReadUInt(5)]
		local Value = ReadValue(net.ReadUInt(3), Field)

		if Field then Values[Field] = Value end
	end

	local Inside = true

	if Values.Origin then
		local Local
		Local, Inside = ToLocalFrame(Values.Origin)

		Values.Origin = Local

		-- ACF's bullet effect decides for itself what to do far away (cl_far.lua keeps it simulated and draws a streak), and a
		-- hit message must always reach it: without it the impact at the end of the flight has nothing to update.
		if not Inside and not SelfManaged[string.lower(Name)] then
			-- Too far out for the engine: a stand-in, or nothing
			if Compat.Far and Compat.Far.Add(Name, Values) then return end

			Stats.EffectsDropped = Stats.EffectsDropped + 1

			return
		end
	end

	local Effect = EffectData()

	for Field, Value in pairs(Values) do
		local Set = Effect["Set" .. Field]

		if Set then Set(Effect, Value) end
	end

	local Before, After = FixEntity(Effect, Values)

	if SelfManaged[string.lower(Name)] then LogBullet(Name, Values, Inside, Before, After) end

	util.Effect(Name, Effect, Allow, Ignore)

	Stats.EffectsShown = Stats.EffectsShown + 1
end)

-- Keeps ACF's own tracer simulation (and the far stand-ins) in step with the player's chunk
local LastChunk

hook.Add("ACF_OnTick", "ACFInfMapCompat_BulletFrame", function()
	local Player = LocalPlayer()

	if not IsValid(Player) then return end

	local Now = Player.CHUNK_OFFSET

	if not Now then return end

	if LastChunk and (LastChunk.x ~= Now.x or LastChunk.y ~= Now.y or LastChunk.z ~= Now.z) then
		local _, Full = Compat.ChunkSizes()
		local Shift   = Vector((LastChunk.x - Now.x) * Full, (LastChunk.y - Now.y) * Full, (LastChunk.z - Now.z) * Full)

		for _, Bullet in pairs(ACF.BulletEffect or {}) do
			if Bullet.SimPos then Bullet.SimPos = Bullet.SimPos + Shift end
			if Bullet.SimPosLast then Bullet.SimPosLast = Bullet.SimPosLast + Shift end

			if IsValid(Bullet.Effect) and Bullet.SimPos and not Bullet.Effect.ACFInfMapFar then Bullet.Effect:SetPos(Bullet.SimPos) end
			if Bullet.Tracer and IsValid(Bullet.Tracer) and Bullet.SimPos then Bullet.Tracer:SetPos(Bullet.SimPos) end
		end

		if Compat.Far then Compat.Far.Shift(Shift) end
	end

	LastChunk = Vector(Now.x, Now.y, Now.z)
end)

-- What did this client receive and what is it simulating? The first thing to run if a tracer or a hit effect is missing.
local function Num(Value) return isnumber(Value) and string.format("%g", Value) or "-" end
local function Pos(Vec) return isvector(Vec) and string.format("(%.0f %.0f %.0f)", Vec.x, Vec.y, Vec.z) or "-" end
local function Flag(Value) if Value == nil then return "n/a" end return Value and "yes" or "NO" end

concommand.Add("acf_infmap_bulletdebug", function()
	print(string.format("[ACF-InfMap] bullet effects this client received (oldest first, last %d). Chunk %s", LogSize, Compat.ChunkText(LocalPlayer())))

	for _, E in ipairs(Compat.BulletLog) do
		print(string.format("  t=%.1f index=%s hit=%s attachment=%s origin=%s inside-window=%s crate-index=%s crate-valid-before-fix=%s after=%s",
			E.Time, Num(E.Index), Num(E.Hit), Num(E.Attachment), Pos(E.Origin), Flag(E.Inside), Num(E.EntIndex), Flag(E.Before), Flag(E.After)))
	end

	print("  simulated right now:")

	local Any = false

	for Index, Bullet in pairs(ACF.BulletEffect or {}) do
		Any = true

		local Effect = Bullet.Effect

		print(string.format("  #%s pos=%s inside-window=%s draws=%s tracer-emitter=%s far=%s effect-valid=%s",
			tostring(Index), Pos(Bullet.SimPos), Flag(isvector(Bullet.SimPos) and Compat.InWindow(Bullet.SimPos)), Flag(Effect and Effect.DrawEffect and true or false),
			Flag(Bullet.Tracer ~= nil and IsValid(Bullet.Tracer)), Flag(Effect and Effect.ACFInfMapFar and true or false), Flag(IsValid(Effect))))
	end

	if not Any then print("  (none)") end
end)

Compat.StatusLines.cl_effects = function()
	local Count = 0

	for _ in pairs(ACF.BulletEffect or {}) do Count = Count + 1 end

	return {
		string.format("effects: you are in chunk %s, %d tracer(s) simulated", Compat.ChunkText(LocalPlayer()), Count),
	}
end
