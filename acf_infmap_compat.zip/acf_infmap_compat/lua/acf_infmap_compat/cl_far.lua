-- Far effects (client): ACF effects and tracers that are too far out for the engine to place.
--
-- Problem: the engine can only place and draw things inside +-16384 units of the frame origin, which under InfMap is the CENTRE
-- of your chunk, not you. Stand near the edge of your chunk and anything more than a few hundred metres the other way is
-- outside that box, however close it is to you. Stock ACF kills a bullet's client-side effect when it leaves the box, and a
-- bullet effect that is gone cannot show its impact either, so hits "stop showing" at a short and seemingly random distance.
--
-- What this module does:
--   1. KEEP-ALIVE. A bullet whose simulated position leaves the window is not killed any more; it just stops being drawn natively.
--      The simulation keeps running, so the hit message still finds it and ACF's own impact code still runs.
--   2. STAND-INS. An effect whose Origin is outside the window (an impact, penetration, ricochet, explosion, smoke burst) is
--      drawn as a simple sprite flash + smoke puff instead, up to `acf_infmap_cl_far_distance` metres from you. The same is
--      done for a tracer streak. The stand-in is drawn at a SHORTENED distance along the same line of sight, scaled down by the
--      same factor, which looks the same from where you stand. (InfMap does the same for props: "shrink" bounds toward the eye,
--      cl_inf_chunks.lua.)
--   3. Effects inside the window are untouched: ACF's own effect code runs as usual.
--
-- Evidence labels: SEEN = read in source / run in the mock, KNOWN = standard GMod behaviour not re-checked, GUESS = needs a game.
--   SEEN:  acf_bullet_effect.lua kills the effect when |x| or |y| > 16380 or z < -16380 of the LOCAL frame, and `Think` then removes
--          its ACF.BulletEffect entry, after which a hit message (Scale > 0) takes the "new bullet" branch and gives up.
--   SEEN:  ACF itself replaces `ApplyMovement` on an effect INSTANCE from the hook ACF_OnCreateBulletEffect
--          (acf/missiles/acfm_effects_cl.lua), so doing the same here is a supported pattern.
--   SEEN:  ACF effects get their size from `Radius` (impacts: the caliber) and `Scale` (explosions: blast radius in units, from
--          Damage.getBlastRadius). Smoke bursts carry their colour in `Start`.
--   KNOWN: render.DrawSprite / render.DrawBeam in PostDrawTranslucentRenderables; materials sprites/light_glow02_add and
--          particle/smokesprites_0001..9 (the last one is used by ACF's own tracer code) and effects/laser1 ship with the game.
--   GUESS: that the engine really does not draw particles/effects outside +-16384. (I believe so from InfMap's own comments,
--          "when bounding box is outside of world bounds the object isn't rendered", and from the engine's coordinate limit.)
--          If it does draw them, you lose nothing: stand-ins are only used outside the window.
--   GUESS: sizes, colours and lifetimes of the stand-ins are eyeballed. `acf_infmap_cl_far_scale` multiplies the size.
--   GUESS: a stand-in is not hidden by terrain between you and it (the shortened position is in front of that terrain). The
--          price of the shortening trick; the same limit applies to InfMap's far props.
--   GUESS: that setting NoDraw on a Lua effect hides it. The Render override does the real work; NoDraw is a second try.

local Compat = ACFInfMapCompat
local Stats  = Compat.Stats

local FarOn    = CreateClientConVar("acf_infmap_cl_far_effects", "1", true, false, "1 = draw simple stand-ins for ACF effects that are too far out for the engine to place. 0 = drop them.", 0, 1)
local FarDist  = CreateClientConVar("acf_infmap_cl_far_distance", "1000", true, false, "Metres. Far stand-ins are drawn up to this distance from you.", 0, 5000)
local FarScale = CreateClientConVar("acf_infmap_cl_far_scale", "1", true, false, "Size multiplier for far stand-ins.", 0.1, 5)

local Far = Compat.Far or {}

Compat.Far = Far
Far.Items  = Far.Items or {}
Far.Errors = Far.Errors or 0

local Near     = 5000 -- A stand-in farther than this is drawn at this distance (scaled down). Eye + 5000 stays inside the window.
local MaxItems = 64

local Styles = {
	acf_impact = "impact", acf_penetration = "impact", acf_ricochet = "impact",
	acf_explosion = "explosion", acf_heat_explosion = "explosion", acf_glatgmexplosion = "explosion", acf_cookoff = "explosion",
	acf_smoke = "smoke",
}

local Life = {impact = 1.5, explosion = 3, smoke = 6}

local GlowMat, SmokeMat, BeamMat

local function Materials()
	GlowMat  = GlowMat or Material("sprites/light_glow02_add")
	SmokeMat = SmokeMat or Material("particle/smokesprites_0003")
	BeamMat  = BeamMat or Material("effects/laser1")
end

local function Number(Value, Default)
	return isnumber(Value) and Value or Default
end

--- Adds a stand-in for an effect. Returns whether one was added (false = nothing will be shown).
--- @param Name string Effect name
--- @param F table Effect fields (Origin is a Vector in the LOCAL frame)
function Far.Add(Name, F)
	if not FarOn:GetBool() then return false end
	if not istable(F) or not isvector(F.Origin) then return false end

	local Kind = Styles[string.lower(tostring(Name))]

	if not Kind then
		Stats.FarDropped = Stats.FarDropped + 1

		return false
	end

	if F.Origin:Distance(EyePos()) > FarDist:GetFloat() * Compat.MeterToUnit then
		Stats.FarDropped = Stats.FarDropped + 1

		return false
	end

	local Item = {Kind = Kind, Pos = F.Origin, Born = CurTime(), Life = Life[Kind]}

	if Kind == "impact" then
		Item.Size  = math.Clamp(Number(F.Radius, 10) * 4, 50, 400)
		Item.Flash = {r = 255, g = 200, b = 120}
		Item.Smoke = {r = 150, g = 140, b = 120}
		Item.Alpha = 110
	elseif Kind == "explosion" then
		Item.Size  = math.Clamp(Number(F.Scale, 300) * 0.8, 150, 3000)
		Item.Flash = {r = 255, g = 170, b = 60}
		Item.Smoke = {r = 70, g = 65, b = 60}
		Item.Alpha = 150
	else
		local C = F.Start

		Item.Size  = math.Clamp(Number(F.Scale, 300), 150, 3000)
		Item.Smoke = isvector(C) and {r = math.Clamp(C.x, 0, 255), g = math.Clamp(C.y, 0, 255), b = math.Clamp(C.z, 0, 255)} or {r = 200, g = 200, b = 200}
		Item.Alpha = 160
	end

	local Items = Far.Items

	Items[#Items + 1] = Item

	if #Items > MaxItems then table.remove(Items, 1) end

	Stats.FarShown = Stats.FarShown + 1

	return true
end

--- Moves every stand-in by `Shift` (the player crossed a chunk border).
function Far.Shift(Shift)
	for _, Item in ipairs(Far.Items) do Item.Pos = Item.Pos + Shift end
end

--- Factor that brings something `Dist` units away to at most `Near` units away along the same line of sight.
local function Factor(Dist)
	if Dist <= Near or Dist == 0 then return 1 end

	return Near / Dist
end

Far.Factor = Factor

local function DrawItem(Item, Eye, Now, MaxUnits, Scale)
	local T = (Now - Item.Born) / Item.Life
	local Dist = Item.Pos:Distance(Eye)

	if Dist > MaxUnits then return end

	local K    = Factor(Dist)
	local Pos  = Eye + (Item.Pos - Eye) * K
	local Size = Item.Size * Scale * K

	if Item.Flash and T < 0.3 then
		local P = T / 0.3
		local S = Size * (1 + P * 1.5)

		render.SetMaterial(GlowMat)
		render.DrawSprite(Pos, S, S, Color(Item.Flash.r, Item.Flash.g, Item.Flash.b, 255 * (1 - P)))
	end

	local S = Size * (0.5 + T * 1.2)

	render.SetMaterial(SmokeMat)
	render.DrawSprite(Pos + Vector(0, 0, Size * T * 0.5), S, S, Color(Item.Smoke.r, Item.Smoke.g, Item.Smoke.b, Item.Alpha * (1 - T)))
end

local function DrawTracer(Bullet, Eye, MaxUnits, Scale)
	local Head, Last = Bullet.SimPos, Bullet.SimPosLast
	local Dist = Head:Distance(Eye)

	if Dist > MaxUnits then return end

	local K     = Factor(Dist)
	local Tail  = Head - (Head - Last) * 3
	local P1    = Eye + (Tail - Eye) * K
	local P2    = Eye + (Head - Eye) * K
	local Width = math.Clamp(Number(Bullet.Caliber, 10) * 3, 4, 40) * Scale * K
	local C     = Bullet.Color

	render.SetMaterial(BeamMat)
	render.DrawBeam(P1, P2, math.max(Width, 0.5), 0, 1, Color(C.r, C.g, C.b, 255))
end

--- Draws everything (called every frame from the hook below; exposed for tests).
function Far.Draw()
	if not FarOn:GetBool() then return end

	Materials()

	local Eye      = EyePos()
	local Now      = CurTime()
	local MaxUnits = FarDist:GetFloat() * Compat.MeterToUnit
	local Scale    = FarScale:GetFloat()
	local Items    = Far.Items

	for I = #Items, 1, -1 do
		local Item = Items[I]

		if Now - Item.Born >= Item.Life then
			table.remove(Items, I)
		else
			DrawItem(Item, Eye, Now, MaxUnits, Scale)
		end
	end

	for _, Bullet in pairs(ACF.BulletEffect or {}) do
		local Effect = Bullet.Effect

		if Effect and Effect.ACFInfMapFar and Effect.DrawEffect and Bullet.Tracer and IsValid(Bullet.Tracer)
			and Bullet.SimPos and Bullet.SimPosLast and Bullet.Color then
			DrawTracer(Bullet, Eye, MaxUnits, Scale)
		end
	end
end

hook.Add("PostDrawTranslucentRenderables", "ACFInfMapCompat_Far", function(_, Skybox, Skybox3D)
	if Skybox or Skybox3D or Far.Disabled then return end

	local OK, Err = pcall(Far.Draw)

	if not OK then
		Far.Errors = Far.Errors + 1

		if Far.Errors >= 5 then
			Far.Disabled = true
			Compat.Warn("Far effect drawing switched itself off after repeated errors. Last error: ", tostring(Err))
		end
	end
end)

-- KEEP-ALIVE: a bullet that leaves the window is simulated but not drawn, instead of being killed.
hook.Add("ACF_OnCreateBulletEffect", "ACFInfMapCompat_KeepAlive", function(Effect)
	if not Effect or Effect.ACFInfMapPatched then return end

	local Move, Draw = Effect.ApplyMovement, Effect.Render

	if not isfunction(Move) then return end

	Effect.ACFInfMapPatched = true

	Effect.ApplyMovement = function(self, Bullet)
		local Pos = Bullet.SimPos

		if Pos and not Compat.InWindow(Pos) then
			if not self.ACFInfMapFar then
				self.ACFInfMapFar = true
				Stats.BulletsKeptAlive = Stats.BulletsKeptAlive + 1

				if self.SetNoDraw then self:SetNoDraw(true) end
			end

			return
		end

		if self.ACFInfMapFar then
			self.ACFInfMapFar = nil

			if self.SetNoDraw then self:SetNoDraw(false) end
		end

		return Move(self, Bullet)
	end

	if isfunction(Draw) then
		Effect.Render = function(self)
			if self.ACFInfMapFar then return end

			return Draw(self)
		end
	end
end)

--- Draws a test stand-in `Meters` metres in front of you, so the far drawing can be checked without shooting.
concommand.Add("acf_infmap_fartest", function(_, _, Args)
	local Meters = tonumber(Args and Args[1]) or 600
	local Pos    = EyePos() + EyeAngles():Forward() * Meters * Compat.MeterToUnit
	local Shown  = Far.Add("ACF_Explosion", {Origin = Pos, Scale = 400})

	Compat.Say("far test ", Meters, " m ahead: ", Shown and "stand-in added (look for a fireball and smoke)" or "not shown (stand-ins are off, or farther than acf_infmap_cl_far_distance)")
end)

Compat.Register("cl_far", function()
	-- ACF's client-side impact effects are created with Effects.CreateEffect from the bullet's simulated position. When that
	-- position is outside the window, draw a stand-in instead of an effect the engine cannot place.
	Compat.Wrap(ACF.Utilities.Effects, "CreateEffect", function(Original)
		return function(Name, Table, AllowOverride, Filter)
			if not FarOn:GetBool() or not Name or not istable(Table) or not isvector(Table.Origin) or Compat.InWindow(Table.Origin) then
				return Original(Name, Table, AllowOverride, Filter)
			end

			local NewName, NewTable = hook.Run("ACF_PreCreateEffect", Name, Table)

			Name  = NewName or Name
			Table = NewTable or Table

			if isvector(Table.Origin) and not Compat.InWindow(Table.Origin) then
				if not Far.Add(Name, Table) then Stats.EffectsDropped = Stats.EffectsDropped + 1 end

				return
			end

			-- A hook moved it inside the window: the tail of the stock function (the hook has already run)
			local Effect = EffectData()

			for Field, Value in pairs(Table) do
				local Set = Effect["Set" .. Field]

				if Set then Set(Effect, Value) end
			end

			util.Effect(Name, Effect, AllowOverride, Filter)
		end
	end, "Effects.CreateEffect (client)")
end)

Compat.StatusLines.cl_far = function()
	local Kept = 0

	for _, Bullet in pairs(ACF.BulletEffect or {}) do
		if Bullet.Effect and Bullet.Effect.ACFInfMapFar then Kept = Kept + 1 end
	end

	return {
		string.format("far effects: %s, up to %g m, size x%g, %d stand-in(s) showing, %d bullet(s) out of the window%s",
			FarOn:GetBool() and "ON" or "OFF", FarDist:GetFloat(), FarScale:GetFloat(), #Far.Items, Kept, Far.Disabled and " (DRAWING DISABLED after errors)" or ""),
	}
end
