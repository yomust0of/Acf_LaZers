-- ACF effects (server half): tracers, muzzle flashes, impacts and explosions get a position the client can place.
--
-- Problem: ACF creates every effect with Effects.CreateEffect, which ends in util.Effect(Name, EffectData). The position
-- inside an EffectData is stored in a small fixed range (about +-16384 units per axis). Under InfMap the server's
-- Entity:GetPos() is a GLOBAL position, so effects in any chunk but the one around the world origin carry a position that
-- does not fit, and the engine also decides who receives the effect from that same wrong position.
--
-- Fix: for server-side effects that have an Origin (or an Entity), the effect is sent in this addon's own net message. It
-- carries the global Origin as three doubles and goes to every player within `acf_infmap_effect_range` of it. The client half
-- (cl_effects.lua) subtracts the local player's chunk, and then builds the EffectData and calls util.Effect itself, so the
-- effect code (muzzle flash, impact, tracer...) is ACF's own and sees an ordinary local position.
--
-- ACF's hook "ACF_PreCreateEffect" is run here, once, exactly as the stock function does, before the message is built.
--
-- Evidence labels: SEEN = read in source / run in the mock, KNOWN = standard GMod behaviour not re-checked, GUESS = needs a game.
--   SEEN:  every ACF effect call goes through Effects.CreateEffect, looked up on ACF.Utilities.Effects at call time. The one
--          exception is acf_missile/init.lua, which calls util.Effect("ACF_Explosion") directly; it is not covered.
--   SEEN:  Effects.CreateEffect: runs hook ACF_PreCreateEffect, fills EffectData via Set<Field> for every key of the table,
--          calls util.Effect(Name, Data, AllowOverride, Filter)                         (core/utilities/effects/effects_sh.lua)
--   SEEN:  bullet tracers: the server sends Origin = global bullet position; the client starts its own simulation from it and
--          ends it after 45 s or beyond 16380 units from the origin                    (ballistics_sv.lua, effects/acf_bullet_effect.lua)
--   SEEN:  only `Origin` is a world position in the effect tables ACF builds. `Start` holds a position in just two places
--          (Sparks from acf_rack and acf_torch), and the Sparks effect is an engine effect that I did not read.
--   KNOWN: an effect's Origin is sent in a limited range, and which clients get an effect is decided from that position.
--          (Exact range from memory of the Source engine's coord encoding, not tested here.)
--   KNOWN: an unreliable net message can be dropped. A lost effect is just a missing flash; a lost bullet "Init" means that
--          bullet has no tracer. That is why effects are unreliable like the stock ones.
--   GUESS: how the stock path misplaces effects in other chunks. It follows from the two KNOWN lines above; nobody has
--          looked at it in game. Turn the fix off with `acf_infmap_fix_effects 0` to compare.
--   GUESS: that net unreliable messages of about 100-250 bytes (a muzzle flash) are accepted by the engine.

local Compat = ACFInfMapCompat
local Stats  = Compat.Stats
local Tag    = Compat.EffectTag

local Fix   = CreateConVar("acf_infmap_fix_effects", "1", Compat.ServerFlags, "1 = send ACF effects with a position the client can place under InfMap. 0 = stock ACF behaviour.", 0, 1)
local Range = CreateConVar("acf_infmap_effect_range", "45000", Compat.ServerFlags, "Players within this many units (global space) of an effect receive it. 39.37 units = 1 metre; the default is about 1.1 km.", 0)

-- Version 2 of this addon shipped 30000 as the default, and FCVAR_ARCHIVE saves whatever value a convar had, so a saved
-- "30000" would hide the new default. That one exact value is treated as "never changed".
if Range:GetFloat() == 30000 then Range:SetFloat(45000) end

util.AddNetworkString("ACFInfMapCompat_Effect")

local function TagOf(Value)
	if isnumber(Value) then return Tag.Number end
	if isvector(Value) then return Tag.Vector end
	if isangle(Value) then return Tag.Angle end
	if isentity(Value) then return Tag.Entity end
	if isbool(Value) then return Tag.Bool end
end

--- The tail of the stock Effects.CreateEffect, without the hook (which has already run).
local function Vanilla(Name, Table, AllowOverride, Filter)
	local Effect = EffectData()

	for Field, Value in pairs(Table) do
		local Set = Effect["Set" .. Field]

		if Set then Set(Effect, Value) end
	end

	util.Effect(Name, Effect, AllowOverride, Filter)
end

local function Write(Tag_, Value)
	if Tag_ == Tag.Number then
		net.WriteDouble(Value)
	elseif Tag_ == Tag.Vector then
		net.WriteDouble(Value.x) net.WriteDouble(Value.y) net.WriteDouble(Value.z)
	elseif Tag_ == Tag.Angle then
		net.WriteFloat(Value.p) net.WriteFloat(Value.y) net.WriteFloat(Value.r)
	elseif Tag_ == Tag.Entity then
		net.WriteEntity(Value)
	else
		net.WriteBool(Value)
	end
end

Compat.Register("sv_effects", function()
	Compat.Wrap(ACF.Utilities.Effects, "CreateEffect", function(Original)
		return function(Name, Table, AllowOverride, Filter)
			if not Fix:GetBool() or not Name or not Table then return Original(Name, Table, AllowOverride, Filter) end

			-- A recipient filter object means the caller chose the audience; leave it alone
			if Filter ~= nil and not isbool(Filter) then return Original(Name, Table, AllowOverride, Filter) end

			local HasEntity = isentity(Table.Entity) and IsValid(Table.Entity)

			-- Nothing to place: stock behaviour
			if not isvector(Table.Origin) and not HasEntity then return Original(Name, Table, AllowOverride, Filter) end

			local NewName, NewTable = hook.Run("ACF_PreCreateEffect", Name, Table)

			Name  = NewName or Name
			Table = NewTable or Table

			local Center = Table.Origin

			if not isvector(Center) then
				local Ent = Table.Entity

				Center = isentity(Ent) and IsValid(Ent) and Ent:GetPos() or nil
			end

			if not Center then return Vanilla(Name, Table, AllowOverride, Filter) end

			local Audience = Compat.PlayersInRange(Center, Range:GetFloat())

			if not Audience[1] then return end

			-- Collect what can be sent
			local Send = {}

			for Field, Value in pairs(Table) do
				local Id, Kind = Compat.EffectFieldId[Field], TagOf(Value)

				if Id and Kind then Send[#Send + 1] = {Id, Kind, Value} end
			end

			net.Start("ACFInfMapCompat_Effect", true)
				net.WriteString(Name)
				net.WriteBool(AllowOverride and true or false)
				net.WriteBool(Filter == true)
				net.WriteUInt(#Send, 5)

				for _, Item in ipairs(Send) do
					net.WriteUInt(Item[1], 5)
					net.WriteUInt(Item[2], 3)
					Write(Item[2], Item[3])
				end
			net.Send(Audience)

			Stats.EffectsSent = Stats.EffectsSent + 1
		end
	end, "Effects.CreateEffect")
end)

Compat.StatusLines.sv_effects = function()
	return {
		string.format("effects: fix %s, range %g units", Fix:GetBool() and "ON" or "OFF", Range:GetFloat()),
	}
end
